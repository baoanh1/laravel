<?php
namespace App;

class CartItem
{
	public $Product;
	public $Quantity;
}