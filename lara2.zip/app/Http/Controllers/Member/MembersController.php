<?php

namespace App\Http\Controllers\Member;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
class MembersController extends Controller
{
    public function showProfile()
    {
    	$user_current_login = Auth::user();
    	return view('Member.Member',['user'=>$user_current_login]);
    }
}
