import VdtnetTable from './VdtnetTable.vue'

export default VdtnetTable
